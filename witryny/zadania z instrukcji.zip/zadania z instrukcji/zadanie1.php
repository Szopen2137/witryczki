<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zadanie 1</title>
</head>
<body>
    <?php
    $liczba = 37;
    if ($liczba % 9 == 0) 
    {
        echo "Liczba $liczba jest podzielna przez 9.";
    }
    else 
    {
        echo "Liczba $liczba nie jest podzielna przez 9.";
    }
    ?>
</body>
</html>